/**
 * WebMessage Handler Module
 * 
 * Handles all communication with the C++ native layer via chrome.webview.postMessage
 * This is a critical module that must be initialized EARLY to catch all messages.
 * 
 * Key responsibilities:
 * - Set up WebMessage listener for C++ → JavaScript communication
 * - Convert screen coordinates to viewport coordinates (DPI scaling)
 * - Dispatch real MouseEvents to DOM for proper event handling
 * - Find interactive elements at click coordinates
 * - Handle CustomEvent dispatching for backward compatibility
 */

import { Coordinates } from '../utils/coordinates';
import { throttle } from '../utils/throttle';
import { logger } from '../utils/logger';
import type { AnyWPSDK } from '../types';
import { isMouseEventData } from '../types/webmessage';
import type { 
  WebMessageEvent, 
  WebMessageData, 
  MouseEventData
} from '../types/webmessage';

// Create scoped logger for WebMessage module
const log = logger.scope('WebMessage');

/**
 * Element cache for performance optimization
 * WeakMap allows automatic garbage collection when elements are removed from DOM
 */
const elementBoundsCache = new WeakMap<Element, { bounds: DOMRect; timestamp: number }>();
const CACHE_TTL = 100; // Cache Time-To-Live: 100ms

/**
 * Interactive elements cache (recomputed when DOM changes)
 */
let cachedInteractiveElements: Element[] = [];
let lastDOMUpdate = Date.now();
const DOM_UPDATE_THROTTLE = 1000; // Check DOM updates every 1 second

/**
 * Initialize WebMessage listener (must be called IMMEDIATELY after script load)
 */
export function setupWebMessageListener(): void {
  if (!(window as any).chrome || !(window as any).chrome.webview) {
    log.info('chrome.webview not available');
    return;
  }
  
  const globalAny = window as any;
  
  // Prevent duplicate listener registration
  if (globalAny._anywpEarlyMessageListenerRegistered) {
    log.warn('WebMessage listener already registered (EARLY), skipping duplicate');
    return;
  }
  
  log.info('Setting up WebMessage listener (EARLY)');
  globalAny._anywpEarlyMessageListenerRegistered = true;
  
  (window as any).chrome.webview.addEventListener('message', handleWebMessage);
  
  log.info('WebMessage listener setup complete (EARLY)');
}

/**
 * Main WebMessage event handler
 */
function handleWebMessage(event: WebMessageEvent): void {
  const data = event.data;
  
  if (!data) {
    log.warn('Received empty WebMessage');
    return;
  }
  
  try {
    // Log selective messages to avoid spam
    logMessage(data);
    
    // Handle different message types using type guards
    if (isMouseEventData(data)) {
      handleMouseEvent(data);
    }
    // Add other message type handlers here as needed
  } catch (error) {
    log.error('Error handling WebMessage:', error);
  }
}

/**
 * Selective logging for WebMessage events
 */
function logMessage(data: WebMessageData): void {
  
  if (data.type === 'mouseEvent' && data.eventType === 'mousemove') {
    // Log every 100th mousemove to avoid spam
    if (!(window as any)._anywp_msg_count) {
      (window as any)._anywp_msg_count = 0;
    }
    (window as any)._anywp_msg_count++;
    
    if ((window as any)._anywp_msg_count % 100 === 0) {
      log.debug('WebMessage received #' + (window as any)._anywp_msg_count + ': ' + data.eventType);
    }
  } else if (data.type === 'mouseEvent') {
    log.debug('WebMessage: ' + data.eventType + ' at (' + data.x + ',' + data.y + ')');
  }
}

/**
 * Handle mouseEvent messages from C++
 */
function handleMouseEvent(data: MouseEventData): void {
  try {
    // v2.0.5+ Convert screen coordinates to viewport coordinates
    // C++ sends physical screen pixels, but we need CSS viewport coordinates
    const AnyWP = (window as any).AnyWP as AnyWPSDK;
    const viewportPos = Coordinates.screenToViewport(data.x, data.y, AnyWP.dpiScale);
    
    log.debug('[CoordinateConversion] Screen (' + data.x + ',' + data.y + ') -> Viewport (' + 
                Math.round(viewportPos.x) + ',' + Math.round(viewportPos.y) + ') DPI:' + AnyWP.dpiScale);
    
    // v2.0.4+ Dispatch REAL MouseEvent to document for proper DOM interaction
    const eventInit: MouseEventInit = {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: viewportPos.x,
      clientY: viewportPos.y,
      screenX: data.x,
      screenY: data.y,
      button: data.button || 0,
      buttons: data.button === 0 ? 1 : 0
    };
    
    // v2.0.6+ Simplified handling for mousemove (performance optimization)
    if (data.eventType === 'mousemove') {
      handleMouseMove(eventInit, data);
      return; // Skip click-specific logic
    }
    
    // Handle click events (mousedown, mouseup, click)
    handleClickEvent(data, eventInit, viewportPos);
  } catch (e) {
    log.error('Error handling mouse event:', e);
  }
}

/**
 * Handle mousemove events (optimized for performance with throttling)
 */
const handleMouseMove = throttle((eventInit: MouseEventInit, data: MouseEventData): void => {
  // For mousemove, just dispatch to document without element search
  // This avoids expensive DOM queries for every mouse movement
  const mousemoveEvent = new MouseEvent('mousemove', eventInit);
  document.dispatchEvent(mousemoveEvent);
  
  // Log every 50th mousemove for debugging
  (window as any)._mousemove_count = ((window as any)._mousemove_count || 0) + 1;
  if ((window as any)._mousemove_count % 50 === 0) {
    log.debug('[DOMDispatch] mousemove #' + (window as any)._mousemove_count + 
                ' at viewport (' + Math.round(eventInit.clientX!) + ',' + Math.round(eventInit.clientY!) + ')');
  }
  
  // Still dispatch CustomEvent for backward compatibility
  const customEvent = new CustomEvent('AnyWP:mouse', {
    detail: {
      type: 'mousemove',
      x: data.x,
      y: data.y,
      button: data.button || 0
    }
  });
  window.dispatchEvent(customEvent);
}, 16); // ~60 FPS throttle (16ms)

/**
 * Get cached or fresh interactive elements
 */
function getInteractiveElements(): Element[] {
  const now = Date.now();
  
  // Recompute cache if TTL expired
  if (now - lastDOMUpdate > DOM_UPDATE_THROTTLE || cachedInteractiveElements.length === 0) {
    const interactiveSelectors = [
      'button', 'a', 'input', 'textarea', 'select',
      '[onclick]', '.clickable', '[role="button"]',
      '.hover-box', '[onmouseenter]', '[onmouseleave]'
    ];
    
    const candidates: Element[] = [];
    for (const selector of interactiveSelectors) {
      const elements = document.querySelectorAll(selector);
      elements.forEach((elem) => {
        if (document.body.contains(elem)) { // Only include elements still in DOM
          candidates.push(elem);
        }
      });
    }
    
    cachedInteractiveElements = candidates;
    lastDOMUpdate = now;
    
    log.debug('[ElementCache] Updated interactive elements cache:', candidates.length, 'elements');
  }
  
  return cachedInteractiveElements;
}

/**
 * Get cached or fresh element bounds
 */
function getElementBounds(elem: Element): DOMRect {
  const now = Date.now();
  const cached = elementBoundsCache.get(elem);
  
  // Return cached bounds if still valid
  if (cached && (now - cached.timestamp) < CACHE_TTL) {
    return cached.bounds;
  }
  
  // Compute fresh bounds
  const bounds = elem.getBoundingClientRect();
  elementBoundsCache.set(elem, { bounds, timestamp: now });
  
  return bounds;
}

/**
 * Handle click events (mousedown, mouseup, click)
 */
function handleClickEvent(data: MouseEventData, eventInit: MouseEventInit, viewportPos: { x: number; y: number }): void {
  // v2.0.5+ Manual element detection using getBoundingClientRect
  // elementFromPoint() doesn't work reliably when wallpaper is below desktop icons
  let targetElement: Element | null = null;
  
  const findElementAtPoint = (x: number, y: number): Element | null => {
    log.debug('[ElementFinder] Searching at viewport coordinates:', x, y);
    log.debug('[ElementFinder] Window size:', window.innerWidth, 'x', window.innerHeight);
    
    // Use cached interactive elements
    const candidates = getInteractiveElements();
    log.debug('[ElementFinder] Found', candidates.length, 'interactive elements (cached)');
    
    // Find the topmost element at the given coordinates
    let found: Element | null = null;
    let maxZIndex = -Infinity;
    
    for (const elem of candidates) {
      // Use cached bounds
      const rect = getElementBounds(elem);
      const isInside = x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
      
      if (isInside) {
        log.debug('[ElementFinder] HIT:', elem.tagName, elem.id || elem.className, 
          'rect:', Math.round(rect.left), Math.round(rect.top), Math.round(rect.right), Math.round(rect.bottom));
        
        const style = window.getComputedStyle(elem);
        const zIndex = style.zIndex === 'auto' ? 0 : parseInt(style.zIndex);
        
        log.debug('[ElementFinder]   zIndex:', zIndex);
        
        if (zIndex >= maxZIndex) {
          maxZIndex = zIndex;
          found = elem;
        }
      }
    }
    
    if (found) {
      log.debug('[ElementFinder] Selected element:', found.tagName, found.id || found.className, 
        'zIndex:', maxZIndex);
    } else {
      log.debug('[ElementFinder] No interactive element found at coordinates');
    }
    
    return found;
  };
  
  targetElement = findElementAtPoint(viewportPos.x, viewportPos.y);
  
  // Create the MouseEvent
  const mouseEvent = new MouseEvent(data.eventType, eventInit);
  
  // Dispatch to the target element or document
  if (targetElement) {
    log.debug('[DOMDispatch] Dispatching', data.eventType, 'to element:', 
                targetElement.tagName, targetElement.id || targetElement.className);
    targetElement.dispatchEvent(mouseEvent);
  } else {
    log.debug('[DOMDispatch] Dispatching', data.eventType, 'to document (no element found)');
    document.dispatchEvent(mouseEvent);
  }
  
  // Log event details
  if (data.eventType === 'mousedown') {
    log.info('[DOMDispatch] mousedown dispatched to', 
                targetElement ? (targetElement.tagName + '#' + (targetElement.id || '?')) : 'document');
  } else if (data.eventType === 'mouseup') {
    log.info('[DOMDispatch] mouseup dispatched to', 
                targetElement ? (targetElement.tagName + '#' + (targetElement.id || '?')) : 'document');
  } else if (data.eventType === 'click') {
    log.info('[DOMDispatch] click dispatched to', 
                targetElement ? (targetElement.tagName + '#' + (targetElement.id || '?')) : 'document');
  }
  
  // Also dispatch CustomEvent for backward compatibility
  const customEvent = new CustomEvent('AnyWP:mouse', {
    detail: {
      type: data.eventType,
      x: data.x,
      y: data.y,
      button: data.button || 0
    }
  });
  window.dispatchEvent(customEvent);
  
  // Also dispatch legacy click event
  if (data.eventType === 'mouseup') {
    const legacyClickEvent = new CustomEvent('AnyWP:click', {
      detail: {
        x: data.x,
        y: data.y
      }
    });
    window.dispatchEvent(legacyClickEvent);
  }
}

/**
 * WebMessage Module
 */
export const WebMessage = {
  setup: setupWebMessageListener
};

