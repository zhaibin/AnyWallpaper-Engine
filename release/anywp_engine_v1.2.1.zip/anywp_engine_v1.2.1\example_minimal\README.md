﻿# AnyWP Engine 绀轰緥锛堟渶灏忛泦鎴愶級

杩欐槸涓€涓渶灏忓彲杩愯鐨?Flutter 妗岄潰椤圭洰锛屾紨绀哄浣曞湪搴旂敤涓泦鎴?AnyWP Engine 棰勭紪璇戝寘銆?

## 浣跨敤姝ラ

1. 纭繚宸茬粡鎸夌収 `setup_precompiled.bat` 瀹夎 AnyWP Engine 棰勭紪璇戝寘銆?
2. 鍦ㄨ绀轰緥鐩綍鎵ц锛?

   ```bash
   flutter pub get
   flutter run -d windows
   ```

3. 鐐瑰嚮椤甸潰涓婄殑 **鈥滃惎鍔ㄥ绾糕€?* 鎸夐挳锛屽嵆鍙湪妗岄潰涓婂姞杞芥寚瀹氱殑缃戦〉銆?

> 鈿狅笍 娉ㄦ剰锛氱ず渚嬩緷璧栬矾寰勯粯璁ゆ寚鍚?`../anywp_engine_v1.2.1`锛岃鏍规嵁鑷韩鐩綍缁撴瀯璋冩暣銆?

