// Wrapper header for Flutter's generated plugin registrant
// This file provides compatibility with Flutter's naming convention
#ifndef ANY_W_P_ENGINE_PLUGIN_H_
#define ANY_W_P_ENGINE_PLUGIN_H_
#include "anywp_engine_plugin_c_api.h"
#endif  // ANY_W_P_ENGINE_PLUGIN_H_
